import requests
import xbmcvfs

patch = xbmcvfs.translatePath('special://home/addons/skin.confluence/1080p/Includes/home_pogoda.xml')

def parser_rambler():
	url = 'https://weather.rambler.ru/api/v3/today/?all_data=0&url_path=v-kambarke'
	data = requests.get(url=url).json()
	for x in data['table_data']:
		return x

def pagoda_data():
    url = 'https://weather.rambler.ru/api/v3/index/?url_path=v-kambarke'
    data = requests.get(url=url).json()
    return data['current_weather']
    

f = open(patch, 'w', encoding='utf-8')
f.write(f'''<?xml version="1.0" encoding="UTF-8"?>
<includes>
	<include name="pogoda">
		<control type="group">
	<animation effect="slide" start="0,0" end="0,-380" time="500" condition="ControlGroup(9003).HasFocus">conditional</animation>
                        <visible>[Integer.IsLessOrEqual(System.time(ss),10)] | [Integer.IsGreater(System.time(ss),20) + Integer.IsLessOrEqual(System.time(ss),30)] | [Integer.IsGreater(System.time(ss),40) + Integer.IsLessOrEqual(System.time(ss),50)]</visible>
			<control type="label">
				<centerright>40%</centerright>
				<top>390</top>
				<width>250</width>
				<height>30</height>
				<align>center</align>
				<aligny>center</aligny>
				<font>font14</font>
				<textcolor>white</textcolor>
				<shadowcolor>black</shadowcolor>
				<label>Камбарка</label>
			</control>

<!--ТЕМПЕРАТУРА-->
   			<control type="label">
				<centerright>42%</centerright>
				<top>470</top>
				<width>150</width>
				<height>30</height>
				<align>right</align>
				<aligny>center</aligny>
				<font>font_MainMenu</font>
				<textcolor>white</textcolor>
				<shadowcolor>black</shadowcolor>
				<label>$NUMBER[{parser_rambler()['temperature'][0]}]</label>
				<visible>Integer.IsGreaterOrEqual(System.Time(HH),00) + Integer.IsLess(System.Time(HH),03)</visible>
			</control>
			<control type="label">
				<centerright>42%</centerright>
				<top>470</top>
				<width>150</width>
				<height>30</height>
				<align>right</align>
				<aligny>center</aligny>
				<font>font_MainMenu</font>
				<textcolor>white</textcolor>
				<shadowcolor>black</shadowcolor>
				<label>$NUMBER[{parser_rambler()['temperature'][1]}]</label>
				<visible>Integer.IsGreaterOrEqual(System.Time(HH),03) + Integer.IsLess(System.Time(HH),06)</visible>
			</control>
			<control type="label">
				<centerright>42%</centerright>
				<top>470</top>
				<width>150</width>
				<height>30</height>
				<align>right</align>
				<aligny>center</aligny>
				<font>font_MainMenu</font>
				<textcolor>white</textcolor>
				<shadowcolor>black</shadowcolor>
				<label>$NUMBER[{parser_rambler()['temperature'][2]}]</label>
				<visible>Integer.IsGreaterOrEqual(System.Time(HH),06) + Integer.IsLess(System.Time(HH),09)</visible>
			</control>
			<control type="label">
				<centerright>42%</centerright>
				<top>470</top>
				<width>150</width>
				<height>30</height>
				<align>right</align>
				<aligny>center</aligny>
				<font>font_MainMenu</font>
				<textcolor>white</textcolor>
				<shadowcolor>black</shadowcolor>
				<label>$NUMBER[{parser_rambler()['temperature'][3]}]</label>
				<visible>Integer.IsGreaterOrEqual(System.Time(HH),09) + Integer.IsLess(System.Time(HH),12)</visible>
			</control>
			<control type="label">
				<centerright>42%</centerright>
				<top>470</top>
				<width>150</width>
				<height>30</height>
				<align>right</align>
				<aligny>center</aligny>
				<font>font_MainMenu</font>
				<textcolor>white</textcolor>
				<shadowcolor>black</shadowcolor>
				<label>$NUMBER[{parser_rambler()['temperature'][4]}]</label>
				<visible>Integer.IsGreaterOrEqual(System.Time(HH),12) + Integer.IsLess(System.Time(HH),15)</visible>
			</control>
			<control type="label">
				<centerright>42%</centerright>
				<top>470</top>
				<width>150</width>
				<height>30</height>
				<align>right</align>
				<aligny>center</aligny>
				<font>font_MainMenu</font>
				<textcolor>white</textcolor>
				<shadowcolor>black</shadowcolor>
				<label>$NUMBER[{parser_rambler()['temperature'][5]}]</label>
				<visible>Integer.IsGreaterOrEqual(System.Time(HH),15) + Integer.IsLess(System.Time(HH),18)</visible>
			</control>
			<control type="label">
				<centerright>42%</centerright>
				<top>470</top>
				<width>150</width>
				<height>30</height>
				<align>right</align>
				<aligny>center</aligny>
				<font>font_MainMenu</font>
				<textcolor>white</textcolor>
				<shadowcolor>black</shadowcolor>
				<label>$NUMBER[{parser_rambler()['temperature'][6]}]</label>
				<visible>Integer.IsGreaterOrEqual(System.Time(HH),18) + Integer.IsLess(System.Time(HH),21)</visible>
			</control>
   			<control type="label">
				<centerright>42%</centerright>
				<top>470</top>
				<width>150</width>
				<height>30</height>
				<align>right</align>
				<aligny>center</aligny>
				<font>font_MainMenu</font>
				<textcolor>white</textcolor>
				<shadowcolor>black</shadowcolor>
				<label>$NUMBER[{parser_rambler()['temperature'][7]}]</label>
				<visible>Integer.IsGreaterOrEqual(System.Time(HH),21) + Integer.IsLess(System.Time(HH),23)</visible>
			</control>
			<control type="label">
				<centerright>42%</centerright>
				<top>470</top>
				<width>150</width>
				<height>30</height>
				<align>right</align>
				<aligny>center</aligny>
				<font>font_MainMenu</font>
				<textcolor>white</textcolor>
				<shadowcolor>black</shadowcolor>
				<label>$NUMBER[{parser_rambler()['temperature'][8]}]</label>
				<visible>Integer.IsGreaterOrEqual(System.Time(HH),23) + Integer.IsLess(System.Time(HH),24)</visible>
			</control>
   			<control type="label">
				<centerleft>63%</centerleft>
				<top>470</top>
				<width>150</width>
				<height>30</height>
				<align>center</align>
				<aligny>center</aligny>
				<font>font14</font>
				<textcolor>blue2</textcolor>
				<shadowcolor>black</shadowcolor>
				<label>$INFO[System.TemperatureUnits]</label>
			</control>
<!--ТЕМПЕРАТУРА-->
   
   
   
   

			<control type="label">
				<centerleft>50%</centerleft>
				<top>540</top>
				<width>700</width>
				<height>33</height>
				<font>font13</font>
				<align>center</align>
				<aligny>center</aligny>
				<label>{pagoda_data()['description_text']}</label>
				<textcolor>grey2</textcolor>
				<shadowcolor>black</shadowcolor>
			</control>
   
<!--Иконка-->
			<control type="image">
				<centerleft>50%</centerleft>
				<top>360</top>
				<width>200</width>
				<height>200</height>
				<aspectratio>keep</aspectratio>
				<texture>weather/icons.default/{parser_rambler()['icon'][0]}.png</texture>
    			<visible>Integer.IsGreaterOrEqual(System.Time(HH),00) + Integer.IsLess(System.Time(HH),03)</visible>
			</control>
   			<control type="image">
				<centerleft>50%</centerleft>
				<top>360</top>
				<width>200</width>
				<height>200</height>
				<aspectratio>keep</aspectratio>
				<texture>weather/icons.default/{parser_rambler()['icon'][1]}.png</texture>
				<visible>Integer.IsGreaterOrEqual(System.Time(HH),03) + Integer.IsLess(System.Time(HH),06)</visible>
			</control>
   			<control type="image">
				<centerleft>50%</centerleft>
				<top>360</top>
				<width>200</width>
				<height>200</height>
				<aspectratio>keep</aspectratio>
				<texture>weather/icons.default/{parser_rambler()['icon'][2]}.png</texture>
				<visible>Integer.IsGreaterOrEqual(System.Time(HH),06) + Integer.IsLess(System.Time(HH),09)</visible>
			</control>
   			<control type="image">
				<centerleft>50%</centerleft>
				<top>360</top>
				<width>200</width>
				<height>200</height>
				<aspectratio>keep</aspectratio>
				<texture>weather/icons.default/{parser_rambler()['icon'][3]}.png</texture>
				<visible>Integer.IsGreaterOrEqual(System.Time(HH),09) + Integer.IsLess(System.Time(HH),12)</visible>
			</control>
			<control type="image">
				<centerleft>50%</centerleft>
				<top>360</top>
				<width>200</width>
				<height>200</height>
				<aspectratio>keep</aspectratio>
				<texture>weather/icons.default/{parser_rambler()['icon'][4]}.png</texture>
				<visible>Integer.IsGreaterOrEqual(System.Time(HH),12) + Integer.IsLess(System.Time(HH),15)</visible>
			</control>
   			<control type="image">
				<centerleft>50%</centerleft>
				<top>360</top>
				<width>200</width>
				<height>200</height>
				<aspectratio>keep</aspectratio>
				<texture>weather/icons.default/{parser_rambler()['icon'][5]}.png</texture>
				<visible>Integer.IsGreaterOrEqual(System.Time(HH),15) + Integer.IsLess(System.Time(HH),18)</visible>
			</control>
   			<control type="image">
				<centerleft>50%</centerleft>
				<top>360</top>
				<width>200</width>
				<height>200</height>
				<aspectratio>keep</aspectratio>
				<texture>weather/icons.default/{parser_rambler()['icon'][6]}.png</texture>
				<visible>Integer.IsGreaterOrEqual(System.Time(HH),18) + Integer.IsLess(System.Time(HH),21)</visible>
			</control>
   			<control type="image">
				<centerleft>50%</centerleft>
				<top>360</top>
				<width>200</width>
				<height>200</height>
				<aspectratio>keep</aspectratio>
				<texture>weather/icons.default/{parser_rambler()['icon'][7]}.png</texture>
    			<visible>Integer.IsGreaterOrEqual(System.Time(HH),21) + Integer.IsLess(System.Time(HH),23)</visible>
			</control>
   			<control type="image">
				<centerleft>50%</centerleft>
				<top>360</top>
				<width>200</width>
				<height>200</height>
				<aspectratio>keep</aspectratio>
				<texture>weather/icons.default/{parser_rambler()['icon'][8]}.png</texture>
				<visible>Integer.IsGreaterOrEqual(System.Time(HH),23) + Integer.IsLess(System.Time(HH),24)</visible>
			</control>
<!--Иконка-->
			<control type="label">
				<centerleft>39%</centerleft>
				<top>390</top>
				<width>300</width>
				<height>30</height>
				<align>center</align>
				<aligny>center</aligny>
				<font>font16</font>
				<textcolor>white</textcolor>
				<label>$INFO[System.Date(ddd dd mmm yy)]</label>
			</control>
   
<!--Влажность %-->
			<control type="image">
				<centerleft>33.8%</centerleft>
				<top>450</top>
				<width>40</width>
				<height>40</height>
				<aspectratio>keep</aspectratio>
      			<colordiffuse>blue2</colordiffuse>
				<texture>weather/humidity.png</texture>
			</control>
			<control type="label">
				<centerleft>34%</centerleft>
				<top>490</top>
				<width>200</width>
				<height>33</height>
				<font>font12</font>
				<align>center</align>
				<aligny>center</aligny>
				<label>$NUMBER[{parser_rambler()['humidity'][0]}]%</label>
				<textcolor>white</textcolor>
				<shadowcolor>black</shadowcolor>
				<visible>Integer.IsGreaterOrEqual(System.Time(HH),00) + Integer.IsLess(System.Time(HH),03)</visible>
			</control>
			<control type="label">
				<centerleft>34%</centerleft>
				<top>490</top>
				<width>200</width>
				<height>33</height>
				<font>font12</font>
				<align>center</align>
				<aligny>center</aligny>
				<label>$NUMBER[{parser_rambler()['humidity'][1]}]%</label>
				<textcolor>white</textcolor>
				<shadowcolor>black</shadowcolor>
				<visible>Integer.IsGreaterOrEqual(System.Time(HH),03) + Integer.IsLess(System.Time(HH),06)</visible>
			</control>
   			<control type="label">
				<centerleft>34%</centerleft>
				<top>490</top>
				<width>200</width>
				<height>33</height>
				<font>font12</font>
				<align>center</align>
				<aligny>center</aligny>
				<label>$NUMBER[{parser_rambler()['humidity'][2]}]%</label>
				<textcolor>white</textcolor>
				<shadowcolor>black</shadowcolor>
				<visible>Integer.IsGreaterOrEqual(System.Time(HH),06) + Integer.IsLess(System.Time(HH),09)</visible>
			</control>
   			<control type="label">
				<centerleft>34%</centerleft>
				<top>490</top>
				<width>200</width>
				<height>33</height>
				<font>font12</font>
				<align>center</align>
				<aligny>center</aligny>
				<label>$NUMBER[{parser_rambler()['humidity'][3]}]%</label>
				<textcolor>white</textcolor>
				<shadowcolor>black</shadowcolor>
				<visible>Integer.IsGreaterOrEqual(System.Time(HH),09) + Integer.IsLess(System.Time(HH),12)</visible>
			</control>
   			<control type="label">
				<centerleft>34%</centerleft>
				<top>490</top>
				<width>200</width>
				<height>33</height>
				<font>font12</font>
				<align>center</align>
				<aligny>center</aligny>
				<label>$NUMBER[{parser_rambler()['humidity'][4]}]%</label>
				<textcolor>white</textcolor>
				<shadowcolor>black</shadowcolor>
				<visible>Integer.IsGreaterOrEqual(System.Time(HH),12) + Integer.IsLess(System.Time(HH),15)</visible>
			</control>
   			<control type="label">
				<centerleft>34%</centerleft>
				<top>490</top>
				<width>200</width>
				<height>33</height>
				<font>font12</font>
				<align>center</align>
				<aligny>center</aligny>
				<label>$NUMBER[{parser_rambler()['humidity'][5]}]%</label>
				<textcolor>white</textcolor>
				<shadowcolor>black</shadowcolor>
				<visible>Integer.IsGreaterOrEqual(System.Time(HH),15) + Integer.IsLess(System.Time(HH),18)</visible>
			</control>
   			<control type="label">
				<centerleft>34%</centerleft>
				<top>490</top>
				<width>200</width>
				<height>33</height>
				<font>font12</font>
				<align>center</align>
				<aligny>center</aligny>
				<label>$NUMBER[{parser_rambler()['humidity'][6]}]%</label>
				<textcolor>white</textcolor>
				<shadowcolor>black</shadowcolor>
				<visible>Integer.IsGreaterOrEqual(System.Time(HH),18) + Integer.IsLess(System.Time(HH),21)</visible>
			</control>
   			<control type="label">
				<centerleft>34%</centerleft>
				<top>490</top>
				<width>200</width>
				<height>33</height>
				<font>font12</font>
				<align>center</align>
				<aligny>center</aligny>
				<label>$NUMBER[{parser_rambler()['humidity'][7]}]%</label>
				<textcolor>white</textcolor>
				<shadowcolor>black</shadowcolor>
				<visible>Integer.IsGreaterOrEqual(System.Time(HH),21) + Integer.IsLess(System.Time(HH),23)</visible>
			</control>
   			<control type="label">
				<centerleft>34%</centerleft>
				<top>490</top>
				<width>200</width>
				<height>33</height>
				<font>font12</font>
				<align>center</align>
				<aligny>center</aligny>
				<label>$NUMBER[{parser_rambler()['humidity'][8]}]%</label>
				<textcolor>white</textcolor>
				<shadowcolor>black</shadowcolor>
				<visible>Integer.IsGreaterOrEqual(System.Time(HH),23) + Integer.IsLess(System.Time(HH),24)</visible>
			</control>
<!--Влажность %-->
<!--Давление мм рт. ст.-->
			<control type="image">
				<centerleft>38.8%</centerleft>
				<top>450</top>
				<width>40</width>
				<height>40</height>
				<aspectratio>keep</aspectratio>
      			<colordiffuse>blue2</colordiffuse>
				<texture>weather/pressure.png</texture>
			</control>
			<control type="label">
				<centerleft>38.8%</centerleft>
				<top>490</top>
				<width>200</width>
				<height>33</height>
				<font>font12</font>
				<align>center</align>
				<aligny>center</aligny>
				<label>$NUMBER[{parser_rambler()['pressure'][0]}]</label>
				<textcolor>white</textcolor>
				<shadowcolor>black</shadowcolor>
				<visible>Integer.IsGreaterOrEqual(System.Time(HH),00) + Integer.IsLess(System.Time(HH),03)</visible>
			</control>
   			<control type="label">
				<centerleft>38.8%</centerleft>
				<top>490</top>
				<width>200</width>
				<height>33</height>
				<font>font12</font>
				<align>center</align>
				<aligny>center</aligny>
				<label>$NUMBER[{parser_rambler()['pressure'][1]}]</label>
				<textcolor>white</textcolor>
				<shadowcolor>black</shadowcolor>
				<visible>Integer.IsGreaterOrEqual(System.Time(HH),03) + Integer.IsLess(System.Time(HH),06)</visible>
			</control>
   			<control type="label">
				<centerleft>38.8%</centerleft>
				<top>490</top>
				<width>200</width>
				<height>33</height>
				<font>font12</font>
				<align>center</align>
				<aligny>center</aligny>
				<label>$NUMBER[{parser_rambler()['pressure'][2]}]</label>
				<textcolor>white</textcolor>
				<shadowcolor>black</shadowcolor>
				<visible>Integer.IsGreaterOrEqual(System.Time(HH),06) + Integer.IsLess(System.Time(HH),09)</visible>
			</control>
   			<control type="label">
				<centerleft>38.8%</centerleft>
				<top>490</top>
				<width>200</width>
				<height>33</height>
				<font>font12</font>
				<align>center</align>
				<aligny>center</aligny>
				<label>$NUMBER[{parser_rambler()['pressure'][3]}]</label>
				<textcolor>white</textcolor>
				<shadowcolor>black</shadowcolor>
				<visible>Integer.IsGreaterOrEqual(System.Time(HH),09) + Integer.IsLess(System.Time(HH),12)</visible>
			</control>
   			<control type="label">
				<centerleft>38.8%</centerleft>
				<top>490</top>
				<width>200</width>
				<height>33</height>
				<font>font12</font>
				<align>center</align>
				<aligny>center</aligny>
				<label>$NUMBER[{parser_rambler()['pressure'][4]}]</label>
				<textcolor>white</textcolor>
				<shadowcolor>black</shadowcolor>
				<visible>Integer.IsGreaterOrEqual(System.Time(HH),12) + Integer.IsLess(System.Time(HH),15)</visible>
			</control>
   			<control type="label">
				<centerleft>38.8%</centerleft>
				<top>490</top>
				<width>200</width>
				<height>33</height>
				<font>font12</font>
				<align>center</align>
				<aligny>center</aligny>
				<label>$NUMBER[{parser_rambler()['pressure'][5]}]</label>
				<textcolor>white</textcolor>
				<shadowcolor>black</shadowcolor>
				<visible>Integer.IsGreaterOrEqual(System.Time(HH),15) + Integer.IsLess(System.Time(HH),18)</visible>
			</control>
   			<control type="label">
				<centerleft>38.8%</centerleft>
				<top>490</top>
				<width>200</width>
				<height>33</height>
				<font>font12</font>
				<align>center</align>
				<aligny>center</aligny>
				<label>$NUMBER[{parser_rambler()['pressure'][6]}]</label>
				<textcolor>white</textcolor>
				<shadowcolor>black</shadowcolor>
				<visible>Integer.IsGreaterOrEqual(System.Time(HH),18) + Integer.IsLess(System.Time(HH),21)</visible>
			</control>
   			<control type="label">
				<centerleft>38.8%</centerleft>
				<top>490</top>
				<width>200</width>
				<height>33</height>
				<font>font12</font>
				<align>center</align>
				<aligny>center</aligny>
				<label>$NUMBER[{parser_rambler()['pressure'][7]}]</label>
				<textcolor>white</textcolor>
				<shadowcolor>black</shadowcolor>
				<visible>Integer.IsGreaterOrEqual(System.Time(HH),21) + Integer.IsLess(System.Time(HH),23)</visible>
			</control>
   			<control type="label">
				<centerleft>38.8%</centerleft>
				<top>490</top>
				<width>200</width>
				<height>33</height>
				<font>font12</font>
				<align>center</align>
				<aligny>center</aligny>
				<label>$NUMBER[{parser_rambler()['pressure'][8]}]</label>
				<textcolor>white</textcolor>
				<shadowcolor>black</shadowcolor>
				<visible>Integer.IsGreaterOrEqual(System.Time(HH),23) + Integer.IsLess(System.Time(HH),24)</visible>
			</control>
<!--Давление мм рт. ст.-->
<!--Ветер м/с-->
			<control type="image">
				<centerleft>43%</centerleft>
				<top>450</top>
				<width>40</width>
				<height>40</height>
				<aspectratio>keep</aspectratio>
      			<colordiffuse>blue2</colordiffuse>
				<texture>weather/wind.png</texture>
			</control>
			<control type="label">
				<centerleft>43%</centerleft>
				<top>490</top>
				<width>200</width>
				<height>33</height>
				<font>font12</font>
				<align>center</align>
				<aligny>center</aligny>
				<label>$NUMBER[{parser_rambler()['wind_speed'][0]}]м/С</label>
				<textcolor>white</textcolor>
				<shadowcolor>black</shadowcolor>
				<visible>Integer.IsGreaterOrEqual(System.Time(HH),00) + Integer.IsLess(System.Time(HH),03)</visible>
			</control>
   			<control type="label">
				<centerleft>43%</centerleft>
				<top>490</top>
				<width>200</width>
				<height>33</height>
				<font>font12</font>
				<align>center</align>
				<aligny>center</aligny>
				<label>$NUMBER[{parser_rambler()['wind_speed'][1]}]м/С</label>
				<textcolor>white</textcolor>
				<shadowcolor>black</shadowcolor>
				<visible>Integer.IsGreaterOrEqual(System.Time(HH),03) + Integer.IsLess(System.Time(HH),06)</visible>
			</control>
   			<control type="label">
				<centerleft>43%</centerleft>
				<top>490</top>
				<width>200</width>
				<height>33</height>
				<font>font12</font>
				<align>center</align>
				<aligny>center</aligny>
				<label>$NUMBER[{parser_rambler()['wind_speed'][2]}]м/С</label>
				<textcolor>white</textcolor>
				<shadowcolor>black</shadowcolor>
				<visible>Integer.IsGreaterOrEqual(System.Time(HH),06) + Integer.IsLess(System.Time(HH),09)</visible>
			</control>
      		<control type="label">
				<centerleft>43%</centerleft>
				<top>490</top>
				<width>200</width>
				<height>33</height>
				<font>font12</font>
				<align>center</align>
				<aligny>center</aligny>
				<label>$NUMBER[{parser_rambler()['wind_speed'][3]}]м/С</label>
				<textcolor>white</textcolor>
				<shadowcolor>black</shadowcolor>
				<visible>Integer.IsGreaterOrEqual(System.Time(HH),09) + Integer.IsLess(System.Time(HH),12)</visible>
			</control>
      		<control type="label">
				<centerleft>43%</centerleft>
				<top>490</top>
				<width>200</width>
				<height>33</height>
				<font>font12</font>
				<align>center</align>
				<aligny>center</aligny>
				<label>$NUMBER[{parser_rambler()['wind_speed'][4]}]м/С</label>
				<textcolor>white</textcolor>
				<shadowcolor>black</shadowcolor>
				<visible>Integer.IsGreaterOrEqual(System.Time(HH),12) + Integer.IsLess(System.Time(HH),15)</visible>
			</control>
   			<control type="label">
				<centerleft>43%</centerleft>
				<top>490</top>
				<width>200</width>
				<height>33</height>
				<font>font12</font>
				<align>center</align>
				<aligny>center</aligny>
				<label>$NUMBER[{parser_rambler()['wind_speed'][5]}]м/С</label>
				<textcolor>white</textcolor>
				<shadowcolor>black</shadowcolor>
				<visible>Integer.IsGreaterOrEqual(System.Time(HH),15) + Integer.IsLess(System.Time(HH),18)</visible>
			</control>
   			<control type="label">
				<centerleft>43%</centerleft>
				<top>490</top>
				<width>200</width>
				<height>33</height>
				<font>font12</font>
				<align>center</align>
				<aligny>center</aligny>
				<label>$NUMBER[{parser_rambler()['wind_speed'][6]}]м/С</label>
				<textcolor>white</textcolor>
				<shadowcolor>black</shadowcolor>
				<visible>Integer.IsGreaterOrEqual(System.Time(HH),18) + Integer.IsLess(System.Time(HH),21)</visible>
			</control>
   			<control type="label">
				<centerleft>43%</centerleft>
				<top>490</top>
				<width>200</width>
				<height>33</height>
				<font>font12</font>
				<align>center</align>
				<aligny>center</aligny>
				<label>$NUMBER[{parser_rambler()['wind_speed'][7]}]м/С</label>
				<textcolor>white</textcolor>
				<shadowcolor>black</shadowcolor>
				<visible>Integer.IsGreaterOrEqual(System.Time(HH),21) + Integer.IsLess(System.Time(HH),23)</visible>
			</control>
   			<control type="label">
				<centerleft>43%</centerleft>
				<top>490</top>
				<width>200</width>
				<height>33</height>
				<font>font12</font>
				<align>center</align>
				<aligny>center</aligny>
				<label>$NUMBER[{parser_rambler()['wind_speed'][8]}]м/С</label>
				<textcolor>white</textcolor>
				<shadowcolor>black</shadowcolor>
				<visible>Integer.IsGreaterOrEqual(System.Time(HH),23) + Integer.IsLess(System.Time(HH),24)</visible>
			</control>
<!--Ветер м/с-->

		</control>

	</include>

</includes>


        ''')


