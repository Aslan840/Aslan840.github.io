
import xbmcgui
import xbmc
import sqlite3

zero = ''
connection = sqlite3.connect('/storage/emulated/0/Android/data/org.xbmc.kodi/files/.kodi/userdata/Database/TV46.db')
cursor = connection.cursor()
cursor.execute('SELECT * FROM channels')
channels = cursor.fetchall()

# Выводим результаты
for user in channels:
  if user[8] == 'Всё ТВ':
      zero = user[1]
connection.close()


if xbmc.getInfoLabel('PVR.ChannelNumberInput') == '':
    xbmc.executebuiltin(f'PlayMedia(pvr://channels/tv/%d0%92%d1%81%d0%b5%20%d0%ba%d0%b0%d0%bd%d0%b0%d0%bb%d1%8b@-1/1@pvr.iptvsimple_{zero}.pvr)')
    xbmc.executebuiltin("Action(Info)")
    xbmc.sleep(2000)
    xbmc.executebuiltin("Action(Info)")

if xbmc.getInfoLabel('PVR.ChannelNumberInput') >= '1':
    xbmc.executebuiltin("Action(Number0)")