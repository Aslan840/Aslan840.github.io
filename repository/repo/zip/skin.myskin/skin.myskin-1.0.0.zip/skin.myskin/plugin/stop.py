
import xbmcgui
import xbmc



xbmc.executebuiltin("Action(Stop)")
xbmc.executebuiltin("ActivateWindow(10000)")