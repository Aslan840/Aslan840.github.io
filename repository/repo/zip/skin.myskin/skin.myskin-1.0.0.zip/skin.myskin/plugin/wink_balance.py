import requests
import xbmc
import xbmcvfs

patch = xbmcvfs.translatePath('special://home/addons/skin.confluence/1080p/Includes/home_balance.xml')

def balance():
    url = 'https://vlg-pnza-itv01.svc.iptv.rt.ru/api/v2/user/account_summary'
    header = {'session_id':'f08f4a80-c4e6-11ee-b023-f063f976f300:38062259:36574414:6'}
    res = requests.get(url=url, headers=header).json()
    itog = str(res['oss_balance'])
    dolg = str(res['oss_refill_amount'])
    return f'{itog[:-2]}.{itog[-2:]}'

def dolg():
    url = 'https://vlg-pnza-itv01.svc.iptv.rt.ru/api/v2/user/account_summary'
    header = {'session_id':'f08f4a80-c4e6-11ee-b023-f063f976f300:38062259:36574414:6'}
    res = requests.get(url=url, headers=header).json()
    itog = str(res['oss_refill_amount'])
    return f'{itog[:-2]}.{itog[-2:]}'


f = open(patch, 'w', encoding='utf-8')
f.write(f'''<?xml version="1.0" encoding="UTF-8"?>
<includes>
	<include name="wink_balance">
 		<control type="group">
   	<animation effect="slide" start="0,0" end="0,-900" time="500" condition="ControlGroup(9003).HasFocus">conditional</animation>
    <visible>[Integer.IsGreater(System.time(ss),10) + Integer.IsLessOrEqual(System.time(ss),20)] | [Integer.IsGreater(System.time(ss),30) + Integer.IsLessOrEqual(System.time(ss),40)] | [Integer.IsGreater(System.time(ss),50) + Integer.IsLessOrEqual(System.time(ss),60)]</visible>
			<top>80</top>
 			<control type="label">
				<centerleft>39%</centerleft>
				<top>310</top>
				<width>300</width>
				<height>30</height>
				<align>center</align>
				<aligny>center</aligny>
				<font>font16</font>
				<textcolor>white</textcolor>
				<label>Ростелеком</label>
			</control>
			<control type="label">
				<centerleft>40%</centerleft>
				<top>385</top>
				<width>300</width>
				<height>30</height>
				<align>center</align>
				<aligny>center</aligny>
				<font>font14</font>
				<textcolor>white</textcolor>
				<shadowcolor>black</shadowcolor>
				<label>[COLOR blue2]Баланс[/COLOR] $NUMBER[{balance()}] ₽</label>
			</control>
			<control type="label">
				<centerleft>40%</centerleft>
				<top>440</top>
				<width>300</width>
				<height>30</height>
				<align>center</align>
				<aligny>center</aligny>
				<font>font14</font>
				<textcolor>white</textcolor>
				<shadowcolor>black</shadowcolor>
				<label>[COLOR blue2]Долг[/COLOR] $NUMBER[{dolg()}] ₽</label>
			</control>
		</control>
	</include>

</includes>

        ''')
xbmc.sleep(5000)
xbmc.executebuiltin("ReloadSkin()")

