#!/usr/bin/env python3 
/system/bin/sh input keyevent 26