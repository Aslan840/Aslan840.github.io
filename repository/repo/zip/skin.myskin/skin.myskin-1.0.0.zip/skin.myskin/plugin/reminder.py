
import xbmcgui
import xbmc

xbmc.sleep(1)
xbmc.executebuiltin("setfocus(11)")

xbmc.executebuiltin("Action(ContextMenu)")
xbmc.sleep(1)
xbmc.executebuiltin("setfocus(1005)")
xbmc.sleep(1)
xbmc.executebuiltin("Action(Select)")
xbmc.sleep(1)
xbmc.executebuiltin("RunScript(special://skin/Plugin/ContextMenu.py)")