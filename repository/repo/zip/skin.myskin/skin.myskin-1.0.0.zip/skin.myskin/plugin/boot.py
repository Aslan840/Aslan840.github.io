import xbmc


xbmc.playSFX('special://skin/extras/startup/boot.wav')

# for x in range(1000):
#     xbmc.sleep(1000)
#     if xbmc.getCondVisibility('[PVR.HasTVChannels]') == True:
#         xbmc.executebuiltin("Action(PlayPvrTV)")
#         break
#     else:
#         continue