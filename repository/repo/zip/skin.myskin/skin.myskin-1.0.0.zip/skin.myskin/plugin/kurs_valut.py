import requests
import xbmc
import xbmcvfs

patch = xbmcvfs.translatePath('special://home/addons/skin.confluence/1080p/includes/home_kurs.xml')

def curs(url):
    res_usd = requests.get(url).json()
    for x in res_usd:
        data = x['rate']
        break
    return str(data)[:-2]


f = open(patch, 'w', encoding='utf-8')
f.write(f'''<?xml version="1.0" encoding="UTF-8"?>
<includes>
	<include name="kurs_valut">
 		<control type="group">
   	<animation effect="slide" start="0,0" end="0,-900" time="500" condition="ControlGroup(9003).HasFocus">conditional</animation>
    <visible>[Integer.IsGreater(System.time(ss),10) + Integer.IsLessOrEqual(System.time(ss),20)] | [Integer.IsGreater(System.time(ss),30) + Integer.IsLessOrEqual(System.time(ss),40)] | [Integer.IsGreater(System.time(ss),50) + Integer.IsLessOrEqual(System.time(ss),60)]</visible>
			<top>80</top>
			<control type="label">
				<centerright>40%</centerright>
				<top>310</top>
				<width>250</width>
				<height>30</height>
				<align>center</align>
				<aligny>center</aligny>
				<font>font14</font>
				<textcolor>white</textcolor>
				<shadowcolor>black</shadowcolor>
				<label>Курс валют</label>
			</control>
			<control type="label">
				<centerright>43%</centerright>
				<top>385</top>
				<width>250</width>
				<height>30</height>
				<align>right</align>
				<aligny>center</aligny>
				<font>font14</font>
				<textcolor>white</textcolor>
				<shadowcolor>black</shadowcolor>
				<label>[COLOR blue2]$[/COLOR]$NUMBER[{curs('https://uranyl.rambler.ru/v1/exchange-rates/USD')}]</label>
			</control>
			<control type="label">
				<centerright>43%</centerright>
				<top>440</top>
				<width>250</width>
				<height>30</height>
				<align>right</align>
				<aligny>center</aligny>
				<font>font14</font>
				<textcolor>white</textcolor>
				<shadowcolor>black</shadowcolor>
				<label>[COLOR blue2]€[/COLOR]$NUMBER[{curs('https://uranyl.rambler.ru/v1/exchange-rates/EUR')}]</label>
			</control>
 		</control>
	</include>
</includes>

        ''')


