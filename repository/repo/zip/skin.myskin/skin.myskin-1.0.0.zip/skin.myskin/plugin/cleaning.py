
import xbmcvfs


xbmcvfs.rmdir("special://home/addons/packages/", True)
xbmcvfs.rmdir("special://home/userdata/Thumbnails/", True)
xbmcvfs.mkdir("special://home/userdata/Thumbnails/")
xbmcvfs.mkdir("special://home/userdata/Thumbnails/0/")
xbmcvfs.mkdir("special://home/userdata/Thumbnails/1/")
xbmcvfs.mkdir("special://home/userdata/Thumbnails/2/")
xbmcvfs.mkdir("special://home/userdata/Thumbnails/3/")
xbmcvfs.mkdir("special://home/userdata/Thumbnails/4/")
xbmcvfs.mkdir("special://home/userdata/Thumbnails/5/")
xbmcvfs.mkdir("special://home/userdata/Thumbnails/6/")
xbmcvfs.mkdir("special://home/userdata/Thumbnails/7/")
xbmcvfs.mkdir("special://home/userdata/Thumbnails/8/")
xbmcvfs.mkdir("special://home/userdata/Thumbnails/9/")
xbmcvfs.mkdir("special://home/userdata/Thumbnails/a/")
xbmcvfs.mkdir("special://home/userdata/Thumbnails/b/")
xbmcvfs.mkdir("special://home/userdata/Thumbnails/c/")
xbmcvfs.mkdir("special://home/userdata/Thumbnails/d/")
xbmcvfs.mkdir("special://home/userdata/Thumbnails/e/")
xbmcvfs.mkdir("special://home/userdata/Thumbnails/f/")
xbmcvfs.mkdir("special://home/userdata/Thumbnails/Video/")







