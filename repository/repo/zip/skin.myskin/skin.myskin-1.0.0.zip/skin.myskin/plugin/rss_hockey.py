import requests
import datetime
import xbmcvfs
date_tedey = datetime.date.today()

url = f'https://www.championat.com/stat/data/{date_tedey}/hockey'
header = {
    'user-agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36'
}

patch = xbmcvfs.translatePath('special://skin/rss/hockey.txt')
f = open(patch, 'w', encoding='utf-8')

res = requests.get(url=url, headers=header).json()
data = res['matches']['hockey']['tournaments']['hockey-6608']['matches']
f.write(f'<rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom"><channel><title>Фонбет Чемпионат КХЛ</title>')
for x in data:
    time = x['time']
    name = x['name']
    f.write(f'<item><title>{time} "{name}" </title> </item>')
f.write(f' </channel></rss>')