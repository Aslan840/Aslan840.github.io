import os
import xbmc
import xbmcaddon
import xbmcgui

from resources.lib.pyftpdlib.authorizers import DummyAuthorizer
from resources.lib.pyftpdlib.handlers import FTPHandler
from resources.lib.pyftpdlib.servers import FTPServer

addon = xbmcaddon.Addon('script.FTPserver')
dialog = xbmcgui.Dialog()
name = addon.getSetting('username')
password = addon.getSetting('password')
path = addon.getSetting('folder')
port = addon.getSetting('port')
ip = addon.getSetting('ip')
ip_avto = xbmc.getIPAddress()

def start_server(name, password, path, ip, port):

    authorizer = DummyAuthorizer()

    authorizer.add_user(name, password, path, perm='elradfmwMT')
    authorizer.add_anonymous(os.getcwd())

    handler = FTPHandler
    handler.authorizer = authorizer

    handler.banner = "pyftpdlib based ftpd ready."

    address = (ip, port)
    server = FTPServer(address, handler)
    server.max_cons = 256
    server.max_cons_per_ip = 5
    server.serve_forever()
    

if __name__ == '__main__':
        # авто
    if addon.getSettingBool('ipauto') == 0:
        
        a = dialog.yesno('FTP server', f'IP Адрес: {ip_avto}:21\nИмя: {name}\nПаролль: {password}')
        if a == 1:
            try:
                start_server(name, password, path, ip_avto, 21)
            except OSError as e:
                if str(e) == '[Errno 13] Permission denied':
                    dialog.ok('FTP server', f'IP Адрес: {ip_avto}:21\nДоступ запрещен')
                if str(e) == '[Errno 99] Cannot assign requested address':
                    dialog.ok('FTP server', f'IP Адрес: {ip_avto}:21\nНеправильно введен адрес')
                if str(e) == '[WinError 10049] Требуемый адрес для своего контекста неверен':
                    dialog.ok('FTP server', f'IP Адрес: {ip_avto}:21\nНеправильно введен адрес')
                if str(e) == '[Errno 98] Address already in use':
                    dialog.ok('FTP server', f'IP Адрес: {ip_avto}:21\nЭтот Сервер Уже Запущен')
                if str(e) == '[WinError 10048] Обычно разрешается только одно использование адреса сокета (протокол/сетевой адрес/порт)':
                    dialog.ok('FTP server', f'IP Адрес: {ip_avto}:21\nЭтот Сервер Уже Запущен')
                print(e)
            else:
                dialog.notification('FTP server', 'Сервер Запущен', xbmcgui. NOTIFICATION_INFO, 5000)
                
            
        # в ручную
    if addon.getSettingBool('ipauto') == 1:
        a = dialog.yesno('FTP server', f'IP Адрес: {ip}:{port}\nИмя: {name}\nПаролль: {password}')
        if a == 1:
            try:
                start_server(name, password, path, ip, port)
            except OSError as e:
                if str(e) == '[Errno 13] Permission denied':
                    dialog.ok('FTP server', f'IP Адрес: {ip}:{port}\nДоступ запрещен')
                if str(e) == '[Errno 99] Cannot assign requested address':
                    dialog.ok('FTP server', f'IP Адрес: {ip}:{port}\nНеправильно введен адрес')
                if str(e) == '[WinError 10049] Требуемый адрес для своего контекста неверен':
                    dialog.ok('FTP server', f'IP Адрес: {ip}:{port}\nНеправильно введен адрес')
                if str(e) == '[Errno 98] Address already in use':
                    dialog.ok('FTP server', f'IP Адрес: {ip}:{port}\nЭтот Сервер Уже Запущен')
                if str(e) == '[WinError 10048] Обычно разрешается только одно использование адреса сокета (протокол/сетевой адрес/порт)':
                    dialog.ok('FTP server', f'IP Адрес: {ip}:{port}\nЭтот Сервер Уже Запущен')
                print(e)
            else:
                dialog.notification('FTP server', 'Сервер Запущен', xbmcgui. NOTIFICATION_INFO, 5000)
                